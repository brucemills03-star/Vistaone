# VistaOne

VistaOne is a starter React Native / Expo media-player application.

## Current build
- VistaOne branded login screen
- Server URL, username and password fields
- iOS and Android project configuration
- Ready for the next development stage

VistaOne should only be used with media and streaming services the user is authorised to access.
